from colorama import init as cl_init
from colorama import Fore
from colorama import Style
import subprocess
import os
import pyttsx3
import datetime as dt
from data import globalvar


cmds_folder = os.path.dirname(os.path.realpath(__file__))
data_folder = os.path.join(cmds_folder, "..", "data")
data_path = os.path.join(data_folder, "data.txt")

with open(data_path, 'r') as file:
            for line in file:
                if line.startswith("voice="):
                    voice = line[len("voice="):].strip()

engine = pyttsx3.init('sapi5')
engine.setProperty('rate', 150)
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[int(voice)].id)



def openprogramm(x):
        open_index = x.find('open ')
        substring = x[open_index + len('open '):]
        print()
        
        if os.path.exists(f'{globalvar.DATA_DIR}/openprogramm.txt'):
            with open(f'{globalvar.DATA_DIR}/openprogramm.txt', 'r') as file:
                for line in file:
                    line = line.strip()
                    parts = line.split(';')

                    text_before_semicolon = parts[0]
                    text_after_semicolon = parts[1] if len(parts) > 1 else ''

                    if text_before_semicolon in substring:
                        print(f'{Fore.MAGENTA}{dt.datetime.now().strftime("[%H:%M:%S]")}{Style.RESET_ALL} Opening {text_before_semicolon}')
                        engine.say(f'Opening {text_before_semicolon}')
                        engine.runAndWait()
                        subprocess.Popen(text_after_semicolon)

def makeownpath():
    engine.say('Please look in the Terminal')
    engine.runAndWait()
    print()
    programm_name = input(f'{Fore.MAGENTA}{dt.datetime.now().strftime("[%H:%M:%S]")}{Style.RESET_ALL} Enter Programm-Name\n> ')
    programm_path = input(f'{Fore.MAGENTA}{dt.datetime.now().strftime("[%H:%M:%S]")}{Style.RESET_ALL} Enter Programm-Path \n> ')

    if not os.path.exists(f'{globalvar.DATA_DIR}/openprogramm.txt'):
         with open(f'{globalvar.DATA_DIR}/openprogramm.txt', 'w') as file:
              file.close()
    with open(f'{globalvar.DATA_DIR}/openprogramm.txt', 'w') as file:
         file.write(f'{programm_name};{programm_path}')