from colorama import init as cl_init
from colorama import Fore
from colorama import Style
import datetime as dt
import os
import pyttsx3
from data import globalvar



cmds_folder = os.path.dirname(os.path.realpath(__file__))
data_folder = os.path.join(cmds_folder, "..", "data")
data_path = os.path.join(data_folder, "data.txt")

with open(data_path, 'r') as file:
            for line in file:
                if line.startswith("voice="):
                    voice = line[len("voice="):].strip()

engine = pyttsx3.init('sapi5')
engine.setProperty('rate', 150)
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[int(voice)].id)



def exit():
        print()
        print(f'{Fore.MAGENTA}{dt.datetime.now().strftime("[%H:%M:%S]")}{Style.RESET_ALL} System will Shutdown in 60 seconds. Please make sure everything is saved.')
        engine.say('System will Shutdown in 60 seconds. Please make sure everything is saved.')
        engine.runAndWait()
        os.system('shutdown /s /t 60')


def afk():
        print()
        print(f'{Fore.MAGENTA}{dt.datetime.now().strftime("[%H:%M:%S]")}{Style.RESET_ALL} Locking System')
        engine.say('Locking System...')
        engine.runAndWait()
        os.system('shutdown /l')

def reload():
        clear = lambda: os.system('cls')
        engine.say('Reloading JARVIS')
        engine.runAndWait()
        clear()
        os.system(f'python {globalvar.JARVIS_DIR}\jarvis.py')
        quit()