import requests
import pyttsx3
from colorama import init as cl_init
from colorama import Fore
from colorama import Style
import datetime as dt
import os

cmds_folder = os.path.dirname(os.path.realpath(__file__))
data_folder = os.path.join(cmds_folder, "..", "data")
data_path = os.path.join(data_folder, "data.txt")
weather_path = os.path.join(data_folder, "weather.txt")

with open(data_path, 'r') as file:
            for line in file:
                if line.startswith("voice="):
                    voice = line[len("voice="):].strip()


engine = pyttsx3.init('sapi5')
engine.setProperty('rate', 150)
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[int(voice)].id)


def weather():
        if not os.path.exists(weather_path):
           engine.say('Please look in the Terminal')
           engine.runAndWait()
           select_api_key = input(f'{Fore.MAGENTA}{dt.datetime.now().strftime("[%H:%M:%S]")}{Style.RESET_ALL} Please type in your API-Key\n> ')
           select_city = input(f'{Fore.MAGENTA}{dt.datetime.now().strftime("[%H:%M:%S]")}{Style.RESET_ALL} Please type in your City\n> ')
           with open(weather_path, 'w') as file:
                file.write(f'''api_key={select_api_key}
city={select_city}''')
        with open(weather_path, 'r') as file:
                for line in file:
                    if line.startswith("api_key="):
                        api_key = line[len("api_key="):].strip()
                    elif line.startswith("city="):
                        city = line[len("city="):].strip()

        weather_data =requests.get(f"https://api.openweathermap.org/data/2.5/weather?q={city}&units=metric&APPID={api_key}")

        #print(weather_data.json())

        temperature = round(weather_data.json()['main']['temp'])
        weather = weather_data.json()['weather'][0]['main']
        description = weather_data.json()['weather'][0]['description']

        print()
        print(f'{Fore.MAGENTA}{dt.datetime.now().strftime("[%H:%M:%S]")}{Style.RESET_ALL} {temperature}°С | {weather}: {description}')
        if weather == 'Clouds':
            engine.say(f'The temperature is {temperature} degrees Celsius. There are {description} in the sky')
            engine.runAndWait()

        elif weather == 'Clear':
            engine.say(f'The temperature is {temperature} degrees Celsius. The Sky is Clear')
            engine.runAndWait()

        elif weather == 'Rain':
            engine.say(f'The temperature is {temperature} degrees Celsius. Its rainy.')
            engine.runAndWait()
        

        else:
            engine.say(f'The temperature is {temperature} degrees Celsius. The Weather is {weather}')
            engine.runAndWait()


def configureWeather():
    engine.say('Please look in the Terminal')
    engine.runAndWait()

    print(f'{Fore.MAGENTA}{dt.datetime.now().strftime("[%H:%M:%S]")}{Style.RESET_ALL} Please type in your API-Key, you got from https://openweathermap.org and your City')
    api_key = input(f'{Fore.MAGENTA}{dt.datetime.now().strftime("[%H:%M:%S]")}{Style.RESET_ALL} API Key > ')
    city = input(f'{Fore.MAGENTA}{dt.datetime.now().strftime("[%H:%M:%S]")}{Style.RESET_ALL} City > ')
    
    if not os.path.exists(weather_path):
        with open(weather_path, 'w') as file:
            file.write('api_key=None')
            file.write('city=None')
    else:     
        lines = []
        with open(weather_path, 'r') as file:
                    for line in file:
                        if line.startswith('api_key'):
                            lines.append(f'api_key={api_key}\n')
                        else:
                            lines.append(line)
        with open(weather_path, 'w') as file:
                    file.writelines(lines)


        lines = []
        with open(weather_path, 'r') as file:
                    for line in file:
                        if line.startswith('city'):
                            lines.append(f'city={city}\n')
                        else:
                            lines.append(line)
        with open(weather_path, 'w') as file:
                    file.writelines(lines)