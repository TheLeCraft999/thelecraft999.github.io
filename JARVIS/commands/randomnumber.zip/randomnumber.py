import random
from colorama import init as cl_init
from colorama import Fore
from colorama import Style
import os
import pyttsx3
import datetime as dt



cmds_folder = os.path.dirname(os.path.realpath(__file__))
data_folder = os.path.join(cmds_folder, "..", "data")
data_path = os.path.join(data_folder, "data.txt")

with open(data_path, 'r') as file:
            for line in file:
                if line.startswith("voice="):
                    voice = line[len("voice="):].strip()

engine = pyttsx3.init('sapi5')
engine.setProperty('rate', 150)
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[int(voice)].id)


def randomnumber(range):
        open_index = range.find('of ')
        substring = range[open_index + len('of '):]
        number = random.randint(1,int(substring))
        print(f'{Fore.MAGENTA}{dt.datetime.now().strftime("[%H:%M:%S]")}{Style.RESET_ALL} The number is: {number}')
        engine.say(f'The number is {number}')
        engine.runAndWait()